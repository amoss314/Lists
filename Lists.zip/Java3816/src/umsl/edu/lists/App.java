package umsl.edu.lists;

import java.util.List;
import java.util.ArrayList;

public class App {

	public static void main(String[] args) {

		List<Shoes> list = new ArrayList<Shoes>();

		App app = new App();

		list.add(app.createShoes("Nike", (int) 7.5, "AirMax"));
		list.add(app.createShoes("ASICS", (int) 11, "Nimbus"));
		list.add(app.createShoes("Adidas", (int) 13, "Shell Toes"));
		list.add(app.createShoes("Saucony", (int) 7, "Freedom"));
		list.add(app.createShoes("Brooks", (int) 8, "Adrenaline"));

		app.printShoes(list);

	}

	public Shoes createShoes(String name, int size, String model) {

		return new Shoes(name, size, model);

	}

	public void printShoes(List<Shoes> list) {

		for (Shoes s : list) {

			System.out.println("Shoe :" + s.getName());
			System.out.println("Size :" + s.getSize());
			System.out.println("Model :" + s.getModel());

			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~");
		}
	}
}
