package umsl.edu.lists;

public class Shoes {

	// original requirements

	String name;
	int size;
	String model;

	public Shoes() {

	}

	public Shoes(String name, int size, String model) {

		this.name = name;
		this.size = size;
		this.model = model;
	}

	// Getters and Setters

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

}
